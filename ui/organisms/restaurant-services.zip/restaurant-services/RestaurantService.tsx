import { Carousel, CarouselProps, Typography } from 'antd';
import { CarouselRef } from 'antd/es/carousel';
import { FC, useRef } from 'react';
import { Heading } from '~/ui/atoms/heading/Heading';
import { NextBackButton } from '~/ui/atoms/next-back-button/NextBackButton';
import styles from './RestaurantService.module.scss';

const { Text } = Typography;
interface Props {
  heading: string;
  description: string;
  items: {
    // src: string;
    title: string;
    description: string;
    onClick?: VoidFunction;
  }[];
  linkButton?: JSX.Element;
}

export const RestaurantService: FC<Props> = ({ heading, description, linkButton, items }) => {
  const configs: CarouselProps = {
    initialSlide: 1,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    centerMode: true,
  };

  const carouselRef = useRef<CarouselRef>(null);

  return (
    <div className={styles['restaurant-services']}>
      <div className={styles['restaurant-services_heading-wrapper']}>
        <Heading level={3} className={styles['restaurant-services_heading']}>
          {heading}
        </Heading>
        <Text className={styles['restaurant-services_description']}>{description}</Text>
        <div className={styles['restaurant-services_buttons']}>
          {linkButton}
          <NextBackButton
            onBack={() => carouselRef.current!.prev()}
            onNext={() => carouselRef.current!.next()}
          />
        </div>
      </div>
      <Carousel
        {...configs}
        ref={carouselRef}
        dots={false}
        className={styles['restaurant-services_items']}
      >
        {items.map((item, idx) => (
          <div key={`${idx}`} className={styles['restaurant-services_item']} onClick={item.onClick}>
            {/* <div className={styles['restaurant-services_img']}>
              <img src={item.src} alt={item.title} />
            </div> */}

            <Text strong className="font-16-18">
              {item.title}
            </Text>
            <Text className="font-14-12 text-grey">{item.description}</Text>
          </div>
        ))}
      </Carousel>
    </div>
  );
};
